package mypack;

public class B {

	public static void main(String[] args) {
		
		Pack.A obj=new Pack.A();
		obj.msg();
	}

}
